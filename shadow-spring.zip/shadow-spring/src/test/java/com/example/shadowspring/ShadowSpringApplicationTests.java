package com.example.shadowspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShadowSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
